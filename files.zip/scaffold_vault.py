#!/usr/bin/env python3
"""
scaffold_vault.py — generate an enterprise-grade Obsidian vault on disk.

Writes a clean folder structure, a pre-configured `.obsidian` (Bases + Properties
enabled, CSS snippets registered, theme set), a Schema.md source-of-truth, starter
.base dashboards, Templater templates, CSS snippets, and a few seed notes. The
result opens in Obsidian fully live — no manual setup.

Usage:
    python scaffold_vault.py --path ./MyVault --name "My Vault"
    python scaffold_vault.py --path ./TeamKB --profile team
    python scaffold_vault.py --path ./AgentMem --profile agent --accent "#6ee7b7"

Profiles:
    pkm    (default)  PARA + Atlas + Daily; projects + reading dashboards
    team              adds People/ CRM + meeting template emphasis
    agent             adds a Memory/ store + agent-memory dashboard (see ref 08)

This script only writes files; it never deletes. It refuses to overwrite a
non-empty target unless --force is given. Always open the result in Obsidian
once to confirm Bases render (Bases syntax evolves across versions).
"""
import argparse
import json
import os
import shutil
import sys
from datetime import date
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
ASSETS = SKILL_ROOT / "assets"

CORE_PLUGINS = [
    "file-explorer", "global-search", "switcher", "graph", "backlink",
    "outgoing-link", "tag-pane", "properties", "page-preview", "templates",
    "note-composer", "command-palette", "editor-status", "bookmarks",
    "outline", "word-count", "file-recovery", "bases",
]

FOLDERS_BASE = ["00-Meta/Templates", "00-Meta/Attachments", "Atlas",
                "Daily", "10-Projects", "20-Areas", "30-Resources/Reading",
                "40-Archive"]


def log(msg):
    print(f"  {msg}")


def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def copy_asset(rel: str, dest: Path):
    src = ASSETS / rel
    if src.exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        return True
    return False


def build_obsidian_config(vault: Path, accent: str, snippets: list[str]):
    cfg = vault / ".obsidian"
    cfg.mkdir(parents=True, exist_ok=True)
    # core + community plugins
    write(cfg / "core-plugins.json", json.dumps(CORE_PLUGINS, indent=2))
    write(cfg / "community-plugins.json", json.dumps([], indent=2))
    # appearance: register + enable snippets, set readable defaults
    appearance = {
        "accentColor": accent,
        "cssTheme": "",                      # default theme; swap to "Minimal" once installed
        "enabledCssSnippets": snippets,
        "baseFontSize": 16,
    }
    write(cfg / "appearance.json", json.dumps(appearance, indent=2))
    # app settings: attachments folder, link style
    app = {
        "attachmentFolderPath": "00-Meta/Attachments",
        "newLinkFormat": "shortest",
        "useMarkdownLinks": False,
        "alwaysUpdateLinks": True,
        "showFrontmatter": True,
    }
    write(cfg / "app.json", json.dumps(app, indent=2))
    # templates core-plugin config
    write(cfg / "templates.json",
          json.dumps({"folder": "00-Meta/Templates"}, indent=2))


def schema_md(profile: str) -> str:
    rows = [
        "| Property | Type | Used on | Allowed values |",
        "|---|---|---|---|",
        "| `type` | Text | every note | project, area, resource, literature, person, meeting, daily, moc, memory |",
        "| `status` | Text | project | active, paused, done, archived |",
        "| `priority` | Number | project | 1 (highest) .. 5 |",
        "| `owner` | Link | project | `[[Person]]` |",
        "| `due` | Date | project | YYYY-MM-DD |",
        "| `created` | Date | most notes | YYYY-MM-DD |",
        "| `rating` | Number | literature | 1 .. 5 |",
        "| `author` | Text | literature | free text |",
        "| `tags` | List | any | controlled vocabulary |",
    ]
    if profile == "agent":
        rows.append("| `topic` | Text | memory | free text |")
        rows.append("| `importance` | Number | memory | 1 .. 5 |")
        rows.append("| `source` | Text | memory | conversation, document, web |")
    body = "\n".join(rows)
    return f"""---
type: moc
title: Schema
created: {date.today().isoformat()}
cssclasses:
  - dashboard
---
# Schema — single source of truth

This note defines the property vocabulary for the vault. Humans **and** agents
must match these names and types exactly, or Bases/Dataview views will break.
Update this note whenever the schema changes.

{body}

## Conventions
- Lowercase keys, used identically everywhere (no `Due` vs `due`).
- Dates are real Date properties (`YYYY-MM-DD`), not quoted strings.
- Properties for structured/queryable data; tags for cross-cutting themes;
  `[[links]]` for relationships.
"""


def readme_md(name: str, profile: str) -> str:
    return f"""---
type: moc
title: Home
cssclasses:
  - dashboard
---
# {name}

Welcome. This vault was scaffolded with the **obsidian-masterclass** skill
({profile} profile).

## Start here
- [[Schema]] — the property vocabulary (read before adding note types)
- Projects dashboard → `10-Projects/projects-dashboard.base`
- Reading shelf → `30-Resources/Reading/reading-tracker.base`
{"- Agent memory → `Memory/agent-memory.base`" if profile == "agent" else ""}

## Next steps
1. Open Settings → Appearance and confirm the CSS snippets are enabled.
2. (Optional) Install the **Minimal** theme, then set it in Appearance.
3. (Optional) Install **Templater** and point its template folder at
   `00-Meta/Templates`, enabling folder templates + trigger-on-create.
4. Add notes; they'll appear in the dashboards automatically.
"""


def seed_notes(vault: Path, profile: str):
    today = date.today().isoformat()
    # a sample project so the dashboard isn't empty
    write(vault / "10-Projects/Sample Project.md", f"""---
type: project
title: Sample Project
status: active
priority: 1
owner: ""
created: {today}
due: {today}
tags:
  - project
cssclasses:
  - project-note
---
# Sample Project

> [!summary] Goal
> Replace this with a real project. It exists so the dashboard renders.

## Milestones
- [ ] First milestone
""")
    write(vault / "30-Resources/Reading/Sample Book.md", f"""---
type: literature
title: Sample Book
author: A. Writer
status: reading
rating: 4
created: {today}
tags:
  - book
---
# Sample Book
A seed note so the reading tracker renders.
""")
    if profile == "agent":
        write(vault / "Memory/Sample Memory.md", f"""---
type: memory
topic: onboarding
importance: 3
created: {today}T09:00:00
source: conversation
links: []
---
# Sample Memory
Seed memory so the agent-memory dashboard renders. See references/08.
""")
    if profile == "team":
        write(vault / "People/Sample Person.md", f"""---
type: person
title: Sample Person
role: ""
created: {today}
tags:
  - person
---
# Sample Person
Lightweight CRM record. Link from meetings and projects via `owner`/`attendees`.
""")


def main():
    ap = argparse.ArgumentParser(description="Generate an enterprise Obsidian vault.")
    ap.add_argument("--path", required=True, help="target directory for the vault")
    ap.add_argument("--name", default=None, help="vault display name (default: dir name)")
    ap.add_argument("--profile", choices=["pkm", "team", "agent"], default="pkm")
    ap.add_argument("--accent", default="#4f8a6b", help="accent color hex")
    ap.add_argument("--force", action="store_true", help="allow non-empty target")
    args = ap.parse_args()

    vault = Path(args.path).resolve()
    name = args.name or vault.name
    if vault.exists() and any(vault.iterdir()) and not args.force:
        sys.exit(f"Refusing to write into non-empty {vault} (use --force).")

    print(f"Scaffolding '{name}' ({args.profile}) at {vault}")
    vault.mkdir(parents=True, exist_ok=True)

    # folders
    folders = list(FOLDERS_BASE)
    if args.profile == "team":
        folders.append("People")
    if args.profile == "agent":
        folders.append("Memory")
    for f in folders:
        (vault / f).mkdir(parents=True, exist_ok=True)
    log(f"folders: {len(folders)}")

    # CSS snippets -> .obsidian/snippets
    snip_dir = vault / ".obsidian" / "snippets"
    snippet_names = []
    for css in ["enterprise-ui.css", "animations.css", "dashboard.css", "callouts.css"]:
        if copy_asset(f"css/{css}", snip_dir / css):
            snippet_names.append(css[:-4])  # name without .css for enabledCssSnippets
    log(f"snippets: {', '.join(snippet_names) or 'none found'}")

    # .obsidian config (enables Bases etc.)
    build_obsidian_config(vault, args.accent, snippet_names)
    log("config: core plugins (incl. Bases), appearance, app, templates")

    # templates -> 00-Meta/Templates
    tdir = vault / "00-Meta" / "Templates"
    tpl_list = ["Daily Note.md", "Project.md", "Meeting.md", "Literature Note.md",
                "tp-user-example.js"]
    if args.profile == "agent":
        tpl_list.append("Memory.md")
    n_tpl = sum(copy_asset(f"templates/{t}", tdir / t) for t in tpl_list)
    log(f"templates: {n_tpl}")

    # bases
    copy_asset("bases/projects-dashboard.base", vault / "10-Projects" / "projects-dashboard.base")
    copy_asset("bases/reading-tracker.base", vault / "30-Resources" / "Reading" / "reading-tracker.base")
    if args.profile == "agent":
        copy_asset("bases/agent-memory.base", vault / "Memory" / "agent-memory.base")
    log("bases: dashboards copied")

    # schema, home, seeds
    write(vault / "00-Meta" / "Schema.md", schema_md(args.profile))
    write(vault / "Home.md", readme_md(name, args.profile))
    seed_notes(vault, args.profile)
    log("schema + home + seed notes")

    print(f"\nDone. Open {vault} as a vault in Obsidian.")
    print("Confirm Bases render and snippets are enabled (Settings → Appearance).")


if __name__ == "__main__":
    main()
