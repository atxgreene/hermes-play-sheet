---
name: obsidian-masterclass
description: >-
  Build and upgrade expert, enterprise-grade Obsidian vaults end to end —
  architecture, the Bases database engine, Dataview/DataviewJS dashboards,
  Templater automation, custom UI with CSS snippets and animations, sync and
  team setups, and programmatic/agent access via the Local REST API + built-in
  MCP server. Use this whenever the user mentions Obsidian, a "vault," .base
  files, Bases, Dataview, Templater, Obsidian CSS/themes/snippets, Obsidian
  Sync, an Obsidian MCP server, or wants to design, scaffold, automate, style,
  troubleshoot, or productionize a Markdown knowledge base / second brain /
  agent memory store — even if they don't say the word "skill." Prefer this
  over improvising from memory; Obsidian changed a lot (Bases, Properties, the
  built-in MCP server) and this skill carries the current details.
---

# Obsidian Masterclass

Build enterprise-grade Obsidian vaults: durable architecture, live database
views, automation, custom UI, robust sync, and a clean programmatic surface for
agents. This file is the orchestration layer — it tells you *how to approach a
vault job* and *which reference to open*. Read the relevant `references/` file
before writing the corresponding artifact; don't reconstruct syntax from memory.

## Mental model (read this first)

Three ideas drive every good decision below:

1. **The whole vault is the database.** Unlike Notion/Airtable, Obsidian has no
   table containers. Every note is a record; structure lives in YAML
   **frontmatter properties**; **Bases** and **Dataview** are *query engines*
   that build live views over notes that already exist. Design the property
   schema first — views are cheap and disposable, schema is forever.
2. **Plain text is the moat.** Notes are `.md`; config is JSON under
   `.obsidian/`; database views are `.base` (YAML); styling is `.css`. An agent
   can construct or repair an *entire vault on disk* without Obsidian running.
   That portability is the reason to choose Obsidian for agent memory.
3. **Two operating modes.** *Offline construction* — write files directly to the
   vault folder (the default for building/scaffolding). *Live connection* —
   talk to a running Obsidian via the Local REST API + MCP server (for operating
   on a vault in use). Pick the mode before you start; see `08`.

Current as of Obsidian **1.10.x** (Bases is a core plugin; Properties and the
built-in MCP server exist). Bases is young and still evolving — always have the
user open a built artifact in Obsidian once to confirm it renders.

## Workflow for "build me a vault"

Do these in order. Skip steps only when the user has already settled them.

1. **Scope the use case and mode.** Personal PKM, team knowledge base, project
   tracker, CRM, agent memory store? Single-user or shared? Offline build or
   live vault? One question max if it's genuinely ambiguous; otherwise state
   your assumption inline and proceed.
2. **Design the architecture.** Folder strategy, property (frontmatter) schema,
   tag taxonomy, naming, MOCs/index notes. → `references/01-vault-architecture.md`
3. **Scaffold it.** Run `scripts/scaffold_vault.py` to lay down folders, a
   `.obsidian` config with sensible defaults, a property schema, starter Bases,
   CSS snippets, and Templater templates in one pass. Then customize. The script
   is the fast path; hand-authoring is fine for small tweaks.
4. **Add live views.** Choose Bases vs Dataview per the matrix below. →
   `references/02-bases.md`, `references/03-dataview.md`
5. **Add automation.** Templater templates + folder templates so notes
   self-structure on creation. → `references/04-templater.md`
6. **Style it.** CSS snippets, `cssclasses`, animations, Style Settings. →
   `references/05-custom-ui-css.md`
7. **Pick the plugin stack.** Only what the job needs; every plugin is attack
   surface and maintenance. → `references/06-plugins.md`
8. **Set up sync + (for teams) security.** → `references/07-sync-and-enterprise.md`
9. **Wire programmatic/agent access** if relevant. → `references/08-agent-integration.md`
10. **Verify.** Open in Obsidian (or have the user do it), confirm Bases render,
    properties parse, snippets load. Troubleshoot with `references/09-troubleshooting.md`.

For a focused request ("just write me a projects dashboard," "make my daily-note
template," "style my callouts"), skip straight to the relevant reference + asset
— don't force the full workflow.

## Decision matrix: Bases vs Dataview vs Notion-style

| Need | Use |
|---|---|
| No-code, fast, editable table/card/list/map views; sort/filter/group by property | **Bases** (core, default choice) |
| Inline fields, heavy computation, custom JS-rendered UI, cross-note rollups Bases can't express | **Dataview / DataviewJS** |
| Truly relational multi-table DB, real-time multi-editor collaboration | Reconsider — that's **Notion's** job, not Obsidian's |

Rule of thumb: **Bases for most list-and-filter jobs; Dataview only when you need
inline fields or real computation; both can coexist in one vault.**

## Decision matrix: sync

| Situation | Recommend |
|---|---|
| Want zero-config, end-to-end encrypted, version history, mobile-solid | **Obsidian Sync** (paid; teams ≤20) |
| Want version control + offsite backup, comfortable with Git | **Obsidian Git** plugin |
| Peer-to-peer, self-hosted, no cloud | **Syncthing** (pair with Git for history) |
| Already living in iCloud/Dropbox/OneDrive | Works, but watch `.obsidian` conflicts; exclude it or use Sync |
| Self-hosted real-time, technical | **Self-hosted LiveSync** (CouchDB) |

Detail and the team-security checklist live in `references/07-sync-and-enterprise.md`.

## Reference map

Open the file that matches the task. Each is self-contained with copy-ready
examples.

- `references/01-vault-architecture.md` — folder strategies (PARA, Johnny.Decimal,
  Zettelkasten, atomic), the property schema as the foundation, tags vs
  properties vs links, naming, MOCs, the `.obsidian` config layout.
- `references/02-bases.md` — full `.base` YAML syntax (filters, formulas,
  properties, summaries, views), view types, functions, worked dashboards,
  embedding, pitfalls. **Open before writing any `.base` file.**
- `references/03-dataview.md` — DQL + DataviewJS, inline fields, dynamic
  dashboards, computed rollups, when to reach past Bases.
- `references/04-templater.md` — `<% %>` vs `<%* %>`, `tp.*` API, interactive
  prompts/suggesters, folder templates, user scripts, self-templating notes.
- `references/05-custom-ui-css.md` — snippet mechanics, the CSS variable system,
  `cssclasses` per-note styling, animations/transitions, Style Settings,
  custom callouts, dashboard layouts.
- `references/06-plugins.md` — curated enterprise plugin stack by job, with the
  "do you actually need this" test and security notes.
- `references/07-sync-and-enterprise.md` — every sync option with tradeoffs,
  conflict handling, backup strategy, the teams security model (Restricted
  Mode, asset bundling, scorecard), commercial licensing.
- `references/08-agent-integration.md` — **the agent differentiator.** Offline
  construction patterns, the Local REST API + built-in MCP server, REST
  endpoints, surgical patching, Obsidian as a structured agent-memory store.
- `references/09-troubleshooting.md` — symptom→cause→fix for the failures that
  actually happen (Bases empty, properties not parsing, snippet won't load,
  sync conflicts, REST/MCP auth).

## Assets (copy-ready)

- `assets/bases/` — working `.base` files: `projects-dashboard.base`,
  `reading-tracker.base`, `agent-memory.base`. Use as templates.
- `assets/templates/` — Templater templates: daily note, meeting, project,
  literature note, plus a `tp.user` script.
- `assets/css/` — snippets: `animations.css` (tasteful transitions),
  `dashboard.css` (card/grid layouts), `callouts.css` (custom callouts),
  `enterprise-ui.css` (compact, professional density).
- `scripts/scaffold_vault.py` — one-command enterprise vault generator. Run
  `python scripts/scaffold_vault.py --help` for options.

## Core principles to enforce in every build

- **Schema before views.** Define properties (with types) before building Bases
  or Dataview. A consistent schema is what makes views work; drift is the #1
  cause of "my Base is empty."
- **Properties for structured/queryable data; tags for cross-cutting themes;
  links for relationships.** Don't overload tags with data that belongs in
  properties.
- **Atomic, well-named notes over deep folders.** Links and queries beat
  hierarchy. Folders are for coarse buckets, not the org chart.
- **Restraint with plugins.** Prefer core (Bases, Properties, Canvas) and a
  short, vetted community list. Each plugin is maintenance + attack surface.
- **Portability is the product.** Never design something that only works with a
  paid service or a single plugin if a plain-text approach exists. The vault
  must survive any tool being removed.
- **Verify in-app.** Bases/Properties/snippets have quirks across versions. A
  build isn't done until it renders.
